-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Lis 27, 2023 at 11:38 AM
-- Wersja serwera: 10.4.28-MariaDB
-- Wersja PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `szkolenia`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `grupa`
--

CREATE TABLE `grupa` (
  `IdSzkolenia` int(11) NOT NULL,
  `Nazwa` varchar(20) DEFAULT NULL,
  `Grupa` varchar(3) DEFAULT NULL,
  `DataRozpoczecia` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `grupa`
--

INSERT INTO `grupa` (`IdSzkolenia`, `Nazwa`, `Grupa`, `DataRozpoczecia`) VALUES
(1, 'Psie przedszkole', 'P1', '2020-10-03'),
(2, 'Posłuszeństwo psa', 'P2', '2020-10-10'),
(3, 'Posłuszeństwo psa', 'P3', '2020-11-07'),
(4, 'Psie przedszkole', 'P4', '2020-11-14');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pies`
--

CREATE TABLE `pies` (
  `Id` int(11) NOT NULL,
  `Idwlasciciela` int(11) DEFAULT NULL,
  `Imie` varchar(30) DEFAULT NULL,
  `Rasa` varchar(30) DEFAULT NULL,
  `DataUrodzenia` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `pies`
--

INSERT INTO `pies` (`Id`, `Idwlasciciela`, `Imie`, `Rasa`, `DataUrodzenia`) VALUES
(1, 1, 'Burek', 'owczarek niemiecki', '2020-07-24'),
(2, 2, 'Piksel', 'akita', '2018-11-17'),
(3, 3, 'Nela', 'basset', '2019-06-19'),
(4, 4, 'Hulk', 'beagle', '2018-12-22'),
(5, 5, 'Suzy', 'bolończyk', '2016-08-16'),
(6, 6, 'Maks', 'wyżeł', '2020-12-19'),
(7, 7, 'Bella', 'yorkshire terrier', '2022-08-17'),
(8, 8, 'Atos', 'corgi', '2019-07-22'),
(9, 9, 'Roky', 'bokser', '2019-06-13'),
(10, 10, 'Yuki', 'west', '2023-04-11'),
(11, 11, 'Brutus', 'owczarek podhalański', '2021-11-11'),
(12, 12, 'Klopsik', 'szpic', '2018-12-27'),
(13, 13, 'Azor', 'owczarek środkowoazjatycki', '2022-07-21'),
(14, 13, 'Sara', 'owczarek szetlandzki', '2019-06-18'),
(15, 14, 'Saba', 'nowofunland', '2023-03-21'),
(16, 15, 'Burek', 'mops', '2020-05-22'),
(17, 16, 'Kiler', 'maltańczyk', '2022-11-18');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `szkolenie`
--

CREATE TABLE `szkolenie` (
  `Id` int(11) NOT NULL,
  `IdPsa` int(11) DEFAULT NULL,
  `IdSzkolenia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `szkolenie`
--

INSERT INTO `szkolenie` (`Id`, `IdPsa`, `IdSzkolenia`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 2),
(6, 6, 2),
(7, 7, 2),
(8, 8, 2),
(9, 9, 3),
(10, 10, 3),
(11, 11, 3),
(12, 12, 3),
(13, 13, 4),
(14, 14, 4),
(15, 15, 4),
(16, 16, 4),
(17, 17, 4);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `wlasciciel`
--

CREATE TABLE `wlasciciel` (
  `Id` int(11) NOT NULL,
  `Imie` varchar(30) DEFAULT NULL,
  `Nazwisko` varchar(30) DEFAULT NULL,
  `AdresMail` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `wlasciciel`
--

INSERT INTO `wlasciciel` (`Id`, `Imie`, `Nazwisko`, `AdresMail`) VALUES
(1, 'Jan', 'Nowak', 'jnowak@wp.pl'),
(2, 'Katarzyna', 'Piotrowska', 'kpiotrowska@wp.pl'),
(3, 'Wioletta', 'Kamas', 'wkamas@wp.pl'),
(4, 'Tomasz', 'Niezgoda', 'tniezgoda@wp.pl'),
(5, 'Joanna', 'Wagner', 'jwagner@wp.pl'),
(6, 'Agnieszka', 'Malinowska', 'amalinowska@wp.pl'),
(7, 'Izabela', 'Kropkiewicz', 'ikropkiewicz@wp.pl'),
(8, 'Jerzy', 'Bukowski', 'jbukowski@wp.pl'),
(9, 'Kazimierz', 'Ciszewski', 'kciszewski@wp.pl'),
(10, 'Anna', 'Kowalkiewicz', 'akowalkiewicz@wp.pl'),
(11, 'Agnieszka', 'Hook', 'ahook@wp.pl'),
(12, 'Agata', 'Malinowska', 'amalinowska@wp.pl'),
(13, 'Anna', 'Babicka', 'ababicka@wp.pl'),
(14, 'Katarzyna', 'Aramowicz', 'karamowicz@wp.pl'),
(15, 'Bartosz', 'Kowalski', 'bkowalski@wp.pl'),
(16, 'Waldemar', 'Latoszek', 'wlatoszek@wp.pl');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `grupa`
--
ALTER TABLE `grupa`
  ADD PRIMARY KEY (`IdSzkolenia`);

--
-- Indeksy dla tabeli `pies`
--
ALTER TABLE `pies`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Idwlasciciela` (`Idwlasciciela`);

--
-- Indeksy dla tabeli `szkolenie`
--
ALTER TABLE `szkolenie`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IdPsa` (`IdPsa`),
  ADD KEY `IdSzkolenia` (`IdSzkolenia`);

--
-- Indeksy dla tabeli `wlasciciel`
--
ALTER TABLE `wlasciciel`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `grupa`
--
ALTER TABLE `grupa`
  MODIFY `IdSzkolenia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pies`
--
ALTER TABLE `pies`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `szkolenie`
--
ALTER TABLE `szkolenie`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `wlasciciel`
--
ALTER TABLE `wlasciciel`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pies`
--
ALTER TABLE `pies`
  ADD CONSTRAINT `pies_ibfk_1` FOREIGN KEY (`Idwlasciciela`) REFERENCES `wlasciciel` (`Id`);

--
-- Constraints for table `szkolenie`
--
ALTER TABLE `szkolenie`
  ADD CONSTRAINT `szkolenie_ibfk_1` FOREIGN KEY (`IdSzkolenia`) REFERENCES `grupa` (`IdSzkolenia`),
  ADD CONSTRAINT `szkolenie_ibfk_2` FOREIGN KEY (`IdPsa`) REFERENCES `pies` (`Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
